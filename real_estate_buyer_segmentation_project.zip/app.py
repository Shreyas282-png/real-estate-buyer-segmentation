
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

st.set_page_config(page_title="Real Estate Buyer Intelligence", page_icon="🏠", layout="wide")

st.title("🏠 AI-Based Real Estate Buyer Segmentation & Investment Profiling")
st.caption("Machine learning dashboard for buyer segmentation, investment behavior and geographic analysis")

@st.cache_data
def load_data():
    df = pd.read_csv("real_estate_buyer_segmentation_dataset.csv")
    df["date_of_birth"] = pd.to_datetime(df["date_of_birth"])
    df["age"] = ((pd.Timestamp("2026-01-01") - df["date_of_birth"]).dt.days / 365.25).round().astype(int)
    return df

df = load_data()

# ---------------- Sidebar filters ----------------
st.sidebar.header("User Controls")
countries = st.sidebar.multiselect("Country", sorted(df["country"].unique()), default=sorted(df["country"].unique()))
regions = st.sidebar.multiselect("Region", sorted(df["region"].unique()), default=sorted(df["region"].unique()))
purposes = st.sidebar.multiselect("Acquisition Purpose", sorted(df["acquisition_purpose"].unique()), default=sorted(df["acquisition_purpose"].unique()))
client_types = st.sidebar.multiselect("Client Type", sorted(df["client_type"].unique()), default=sorted(df["client_type"].unique()))

# ---------------- Data preparation ----------------
features_cat = ["client_type", "gender", "country", "region",
                "acquisition_purpose", "loan_applied", "referral_channel"]
features_num = ["age", "satisfaction_score"]

preprocessor = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"), features_cat),
    ("num", StandardScaler(), features_num)
])

X = preprocessor.fit_transform(df[features_cat + features_num])

# Evaluate possible K values.
evaluation = []
for k in range(2, 7):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X)
    evaluation.append({
        "k": k,
        "silhouette": silhouette_score(X, labels),
        "inertia": km.inertia_
    })

eval_df = pd.DataFrame(evaluation)

# The project specification recommends four business segments.
# Four clusters also provide clear, interpretable buyer profiles in this synthetic dataset.
best_k = 4
model = KMeans(n_clusters=best_k, random_state=42, n_init=10)
df["cluster"] = model.fit_predict(X)

summary = df.groupby("cluster").agg(
    customers=("client_id", "count"),
    avg_age=("age", "mean"),
    avg_satisfaction=("satisfaction_score", "mean"),
    investment_share=("acquisition_purpose", lambda x: (x == "Investment").mean()),
    corporate_share=("client_type", lambda x: (x == "Corporate").mean()),
    loan_share=("loan_applied", lambda x: (x == "Yes").mean())
).reset_index()

def name_cluster(row):
    if row["corporate_share"] >= 0.50:
        return "Corporate Buyers"
    if row["loan_share"] >= 0.55 and row["avg_age"] < 38:
        return "First-Time Buyers"
    if row["avg_satisfaction"] >= 4.60 and row["avg_age"] >= 50:
        return "Luxury Investors"
    return "Global Investors"

summary["buyer_type"] = summary.apply(name_cluster, axis=1)
name_map = dict(zip(summary["cluster"], summary["buyer_type"]))
df["buyer_type"] = df["cluster"].map(name_map)

filtered = df[
    df["country"].isin(countries) &
    df["region"].isin(regions) &
    df["acquisition_purpose"].isin(purposes) &
    df["client_type"].isin(client_types)
].copy()

# ---------------- Dashboard ----------------
tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Segmentation Overview",
    "💰 Investor Behavior",
    "🌍 Geographic Analysis",
    "🔎 Segment Insights"
])

with tab1:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Buyers", f"{len(filtered):,}")
    c2.metric("Buyer Segments", "4")
    c3.metric("Avg Satisfaction", f"{filtered['satisfaction_score'].mean():.2f}/5")
    c4.metric("Investment Buyers", f"{filtered['acquisition_purpose'].eq('Investment').mean()*100:.1f}%")

    seg_counts = filtered["buyer_type"].value_counts().reindex(
        ["Global Investors", "First-Time Buyers", "Corporate Buyers", "Luxury Investors"]
    ).fillna(0).reset_index()
    seg_counts.columns = ["Buyer Type", "Customers"]

    fig = px.bar(seg_counts, x="Buyer Type", y="Customers",
                 title="Buyer Segment Distribution", text="Customers")
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Model Validation")
    left, right = st.columns(2)

    with left:
        fig1 = px.line(eval_df, x="k", y="silhouette", markers=True,
                       title="Silhouette Score by Number of Clusters",
                       labels={"k": "Number of Clusters", "silhouette": "Silhouette Score"})
        st.plotly_chart(fig1, use_container_width=True)

    with right:
        fig2 = px.line(eval_df, x="k", y="inertia", markers=True,
                       title="Elbow / Inertia Curve",
                       labels={"k": "Number of Clusters", "inertia": "Inertia"})
        st.plotly_chart(fig2, use_container_width=True)

with tab2:
    behavior = filtered.groupby("buyer_type").agg(
        Buyers=("client_id", "count"),
        Avg_Age=("age", "mean"),
        Investment_Rate=("acquisition_purpose", lambda x: (x == "Investment").mean() * 100),
        Loan_Rate=("loan_applied", lambda x: (x == "Yes").mean() * 100),
        Avg_Satisfaction=("satisfaction_score", "mean")
    ).reset_index()

    for col in ["Avg_Age", "Investment_Rate", "Loan_Rate", "Avg_Satisfaction"]:
        behavior[col] = behavior[col].round(2)

    st.dataframe(behavior, use_container_width=True, hide_index=True)

    fig = px.bar(behavior, x="buyer_type", y="Investment_Rate",
                 title="Investment Rate by Buyer Segment",
                 labels={"buyer_type": "Buyer Segment", "Investment_Rate": "Investment Rate (%)"})
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    geo = filtered.groupby(["country", "buyer_type"]).size().reset_index(name="buyers")
    fig = px.bar(geo, x="country", y="buyers", color="buyer_type",
                 barmode="stack", title="Buyer Segments by Country")
    st.plotly_chart(fig, use_container_width=True)

    reg = filtered["region"].value_counts().reset_index()
    reg.columns = ["Region", "Buyers"]
    fig2 = px.pie(reg, names="Region", values="Buyers",
                  title="Buyer Distribution by Region")
    st.plotly_chart(fig2, use_container_width=True)

with tab4:
    available_segments = [
        s for s in ["Global Investors", "First-Time Buyers", "Corporate Buyers", "Luxury Investors"]
        if s in filtered["buyer_type"].unique()
    ]
    selected = st.selectbox("Select buyer segment", available_segments)
    s = filtered[filtered["buyer_type"] == selected]

    col1, col2, col3 = st.columns(3)
    col1.metric("Customers", len(s))
    col2.metric("Average Age", f"{s['age'].mean():.1f}")
    col3.metric("Average Satisfaction", f"{s['satisfaction_score'].mean():.2f}/5")

    st.write("### Key Characteristics")
    st.write(f"- **Investment purpose:** {s['acquisition_purpose'].eq('Investment').mean()*100:.1f}%")
    st.write(f"- **Loan usage:** {s['loan_applied'].eq('Yes').mean()*100:.1f}%")
    st.write(f"- **Corporate clients:** {s['client_type'].eq('Corporate').mean()*100:.1f}%")
    st.write(f"- **Top country:** {s['country'].value_counts().idxmax()}")
    st.write(f"- **Top referral channel:** {s['referral_channel'].value_counts().idxmax()}")

st.divider()
st.caption("Synthetic dataset created for educational/project demonstration purposes.")
