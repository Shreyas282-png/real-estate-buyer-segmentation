# Real Estate Buyer Segmentation Project

Main files:
- app.py — Streamlit dashboard
- real_estate_buyer_segmentation_dataset.csv — 500-row synthetic dataset
- real_estate_buyer_segmentation_dataset.xlsx — Excel dataset
- requirements.txt — deployment dependencies
- project_report.txt — research/project report content
